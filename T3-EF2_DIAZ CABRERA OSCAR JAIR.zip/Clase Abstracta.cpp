/////////////////////////// UNA CLASE ABSTRACTA
#include <iostream>
#include <cstdlib>

using namespace std;

///// SUPERCLASE
class Impresora{
	public:
		virtual int Arrancar()=0;
};
///// CLASE DERIVADA
class ChorroTinta: public Impresora{
	protected:
		float chorro;
	public:
		int Arrancar(){return 100;}
};
////// CLASE DERIVADA
class Matricial: public Impresora{
	protected:
		int Agujas;
	public:
		int Arrancar(){return 10;}
};

//////////////////////////////////////
int main(int argc, char **argv){
	// Impresora im;		no se puede declaras porque es abstracta
	Matricial m;
	ChorroTinta ch;
	
	cout<< "Arrancar Matricial: "<< m.Arrancar()<< endl;
	cout<< "Arrancar ChorroTinta: "<< ch.Arrancar()<<endl;
	
	
	system("PAUSE");
	return EXIT_SUCCESS;
}











