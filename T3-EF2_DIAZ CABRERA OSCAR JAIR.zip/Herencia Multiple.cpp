////////////////// HERENCIA MULTIPLE SIN PROBLEMAS DE COLISION DE NOMBRES O 
////////////////// DE HERENCIA REPETIDA
#include<iostream>
#include<cstdlib>

using namespace std;

// CLASE PADRE
class A{
	protected:
		int Entero;
	public:
		A(){		//condstructor por defecto
		}
		A(int i){ Entero = i;}		//constructor alternativo
		
		// set y get del entero
		void setEntero( int i ){ Entero = i;}
		int getEntero(){ return Entero;}
};

// CLASE PADRE
class B{
	protected:
		char Letra;
	public:
		B(){			//constructor por defecto
		}
		B(char c){ Letra=c;	}	//constructor alternativo
		
		//set y get de la Letra
		void setLetra(char c){ Letra=c; }
		char getLetra(){ return Letra; }
};

// LA CLASE C HEREDA DE LAS DOS CLASES PADRES A Y B
class C: public A, public B{
	private:
		float Real;
	public:
		C(){			//constructor por defecto
		}
		C(int, char, float); 	//constructor alternativo
		
		//set y get para el Real
		void setReal(float r){ Real=r;}
		float getReal(){ return Real;}
};

//Definicion del constructor de la clase C, Donde esta llamando a 
// los constructores de las clases padres A Y B
// ademas inicializa el atributo propio de C
C::C(int i, char c, float f) : A(i), B(c){	//garantiza que las clases padre sean correctamente iniciloizadas antes de que la subclase C haga sus propias asignaciones

	Real=f;
}

//////////////////////////////////////////////////////
int main(int argc, char **argv){
	// obtencion de datos al objeto C
	C c1(23, 'C', 24.5);
	
	//se muestran los datos
	cout<< c1.getEntero()<<endl;
	cout<< c1.getLetra()<<endl;
	cout<< c1.getReal()<<endl;
	
	
	system("PAUSE");
	return EXIT_SUCCESS;
	
}







