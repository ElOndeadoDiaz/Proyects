//////////////////////// 	HERENCIA MULITPLE CON COLISION DE NOMBRE
/////////////////////// REPETICION DE UN ATRIBUTO EN LAS CLASES BASE Y DERIVADA
#include<iostream>
#include<cstdlib>

using namespace std;

//SUPERCLASE
class B1{
	protected:
		int x;
};
//SUPERCLASE
class B2{
	protected:
		int x;
};
//SUBLCASE CON HERENCIA MULTTIPLE
class C: public B1, B2{
	protected:
		int x;
	public:
		friend void Probar();		//es amiga y tiene acceso a x
		void verX(){
			cout<< "x de C: "<< x<<endl;				// x de C
			cout<< "x de B1: "<< B1::x<<endl;			//x de B1
			cout<< "x de B2: "<< B2::x<<endl;			//x de B2
		}
};

void Probar(){
	C c1;		
	
	c1.x=12;		//atribuito x de C
	c1.B1::x=123;		//atributo x de B1 resolcuion de colision
	c1.B2::x=143;		////atributo x de B2 resolcuion de colision
	
	cout<< "Desde la funcion amiga Probar(): \n";
	c1.verX();
}
///////////////////////////////////////////////////////
int main(int argc, char **argv){
	
	Probar(); //llamar a la funcion que prueba la herencia multiple
	
	system("PAUSE");
	return EXIT_SUCCESS;
	
}
///////////////////////////////////////////////////////








