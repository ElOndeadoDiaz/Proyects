////////////////// HERENCIA SIMPLE ///////////////////////////////////

#include <cstdlib>
#include <iostream>

using namespace std;

// SUPERCLASE
class Persona{
	protected:
		char Nombre[40];
	public:
		Persona(){	//constructor
		}
		
		//configuracion y obtencion del nombre de la persona
		void setNombre(char *s){strcpy(Nombre, s);}
		char *getNombre(){ return Nombre;}
};

// SUBCLASE
class Estudiante: public Persona{
	protected:
		char Estudios[30];
	public:
		Estudiante(){		//constructor
		}
		
		//configuracion y obtencion de los estudios del estudiante
		void setEstudios(char *c){strcpy(Estudios, c);}
		char *getEstudios(){ return Estudios;}
};

//SUBCLASE
class Empleado: public Persona{
	private:
		float Sueldo;
	public:
		Empleado(){	//constructor
		}
		
		//config y obtencion del sueldo del empleado
		void setSueldo(float r){ Sueldo=r;}
		float getSueldo(){ return Sueldo;}
};
/////////////////////////////////////////////
int main(int argc, char **argv){
	
	
	system("PAUSE");
	return EXIT_SUCCESS;
}
///////////////////////////////////////////////
