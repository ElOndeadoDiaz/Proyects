#include <cstdlib>
#include <string.h>
#include <iostream>

using namespace std;

//////////////// CLASE PADRE /////////////////////////
class Publicacion
{
public:
	void NombrarEditor(const char *s){strcpy (editor,s);}
	void PonerFecha(unsigned long fe){ fecha = fe;}
	void EscribirEditor(){ cout << editor << endl;}
	void EscribirFecha(){ cout << fecha << endl;}
private:
	char editor[50];
	unsigned long fecha;
};
////////////////////// Para tesis
class Tesis :public Publicacion{
	private:
		char _strAutor[100];
		int _intGen;
	public:
		void setAutor(const char *s){strcpy(_strAutor,s);}
		void setGeneracion(int gen){_intGen=gen;};
		void getAutor(){cout <<_strAutor<< endl;}
		void getGeneracion(){cout << _intGen << endl;}
};

///////////// Para revista
class Revista :public Publicacion
{
public:
	void NumerosPorAnyo(unsigned n){ numerosPorAnyo = n;}
	void FijarCirculacion(unsigned long n){ circulacion = n;}
	void EscribirNumerosPorAnyo(){ cout << numerosPorAnyo << endl;}
	void EscribirCirculacion(){ cout << circulacion << endl;}
private:
	unsigned numerosPorAnyo;
	unsigned long circulacion;
};

class Libro :public Publicacion
{
//////////////// libro
public:
	void PonerISBN(const char *s){ strcpy(ISBN,s);}
	void PonerAutor(const char *s){ strcpy(autor,s);}
	void EscribirISBN(){ cout << ISBN << endl;}
	void EscribirAutor(){ cout << autor << endl;}
private:
	char ISBN[20];
	char autor[40];
};

////////////////////////////////////////////////////////////////
int main(int argc, char *argv[])
{
	Libro L;
	Revista R;
	Tesis T;
	
	// Ingreso de datos
	L.NombrarEditor("McGraw-Hill serie Schaum");
	L.PonerFecha(23052005);
	L.PonerISBN("84-481-4514-3");
	L.PonerAutor("Sanchez, García Lucas");
	R.NombrarEditor("McGraw-Hill");
	R.PonerFecha(1106005);
	R.NumerosPorAnyo(12);
	R.FijarCirculacion(20000);
	T.NombrarEditor("UACM");
	T.PonerFecha(18032025);
	T.setAutor("Diaz Oscar");
	T.setGeneracion(2023);
	
	// Se muestran los datos
	cout <<"LIBRO\n\n";
	L.EscribirAutor();
	L.EscribirEditor();
	L.EscribirFecha();
	L.EscribirISBN();
	
	cout<<"\nREVISTA\n\n";
	
	R.EscribirCirculacion();
	R.EscribirEditor();
	R.EscribirFecha();
	R.EscribirNumerosPorAnyo();
	
	cout<<"\nTESIS\n\n";
	T.getAutor();
	T.getGeneracion();
	T.EscribirEditor();
	T.EscribirFecha();
	
	
system("PAUSE");
return EXIT_SUCCESS;
}
////////////////////////////////////////////////////////////////////