///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
interface PorPagar 
{    
   double obtenerMontoPago(); // calcula el pago; no hay implementación
   double getImpuestos();// calcula los impuestos 

} // fin de la interfaz PorPagar

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
public class PruebaInterfazPorPagar 
{
   public static void main( String[] args )
   {
      // crea arreglo PorPagar con cuatro elementos
      PorPagar[] objetosPorPagar = new PorPagar[ 4 ];
      
      // llena el arreglo con objetos que implementan la interfaz PorPagar
      objetosPorPagar[ 0 ] = new Factura( "01234", "asiento", 2, 375.00, 0.16 );
      objetosPorPagar[ 1 ] = new Factura( "56789", "llanta", 4, 79.95, 0.16 );
      objetosPorPagar[ 2 ] = new EmpleadoAsalariado( "John", "Smith", "111-11-1111", 800.00, 0.33 );
      objetosPorPagar[ 3 ] = new EmpleadoAsalariado( "Lisa", "Barnes", "888-88-8888", 1200.00, 0.33 );

      System.out.println( 
         "Facturas y Empleados procesados en forma polimorfica:\n" ); 

      // procesa en forma genérica cada elemento en el arreglo objetosPorPagar
      for ( PorPagar porPagarActual : objetosPorPagar )
      {
         // imprime porPagarActual y su monto de pago apropiado
         System.out.printf( "%s \n%s: $%,.2f\n\n", 
            porPagarActual.toString(), 
            "pago vencido", porPagarActual.obtenerMontoPago() ); 
      } // fin de for
   } // fin de main
} // fin de la clase PruebaInterfazPorPagar

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Factura implements PorPagar
{
   private String numeroPieza; 
   private String descripcionPieza;
   private int cantidad;
   private double precioPorArticulo;
   private double impuesto;

   // constructor con cuatro argumentos
   public Factura( String pieza, String descripcion, int cuenta, double precio, double imp )
   {
      numeroPieza = pieza;
      descripcionPieza = descripcion;
      establecerCantidad( cuenta ); // valida y almacena la cantidad
      establecerPrecioPorArticulo( precio ); // valida y almacena el precio por artículo
      setImpuesto( imp );
   } // fin del constructor de Factura con cuatro argumentos

    public void setImpuesto(double imp){
        if ( imp >= 0)
            impuesto = imp;
        else    
            throw new IllegalArgumentException( "El impuesto debe ser >=0" );
    }
    
    public double getImpuestos(){
        return obtenerMontoPago()*impuesto;
    }

   // establece el número de pieza
   public void establecerNumeroPieza( String pieza )
   {
      numeroPieza = pieza;  // debería validar  
   } // fin del método establecerNumeroPieza

   // obtiene el número de pieza
   public String obtenerNumeroPieza()
   {
      return numeroPieza;
   } // fin del método obtenerNumeroPieza

   // establece la descripción
   public void establecerDescripcionPieza( String descripcion )
   {
      descripcionPieza = descripcion;  // debería validar
   } // fin del método establecerDescripcionPieza

   // obtiene la descripción
   public String obtenerDescripcionPieza()
   {
      return descripcionPieza;
   } // fin del método obtenerDescripcionPieza

   // establece la cantidad
   public void establecerCantidad( int cuenta )
   {
      if ( cuenta >= 0 )
         cantidad = cuenta;
      else
         throw new IllegalArgumentException ( "Cantidad debe ser >= 0" );
   } // fin del método establecerCantidad

   // obtener cantidad
   public int obtenerCantidad()
   {
      return cantidad;
   } // fin del método obtenerCantidad

   // establece el precio por artículo
   public void establecerPrecioPorArticulo( double precio )
   {
      if ( precio >= 0.0 )
         precioPorArticulo = precio;
      else
         throw new IllegalArgumentException(
            "El precio por articulo debe ser >= 0" );
   } // fin del método establecerPrecioPorArticulo

   // obtiene el precio por artículo
   public double obtenerPrecioPorArticulo()
   {
      return precioPorArticulo;
   } // fin del método obtenerPrecioPorArticulo

   // devuelve representación String de un objeto Factura
   @Override
   public String toString()
   {
      return String.format( "%s: \n%s: %s (%s) \n%s: %d \n%s: $%,.2f\n%s: $%,.2f", 
         "factura", "numero de pieza", obtenerNumeroPieza(), obtenerDescripcionPieza(), 
         "cantidad", obtenerCantidad(), "precio por articulo", obtenerPrecioPorArticulo(), "impuesto", getImpuestos() );
   } // fin del método toString

   // método requerido para realizar el contrato con la interfaz PorPagar
   @Override
   public double obtenerMontoPago() 
   {
      return obtenerCantidad() * obtenerPrecioPorArticulo(); // calcula el costo total
   } // fin del método obtenerMontoPago
} // fin de la clase Factura

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
abstract class Empleado implements PorPagar
{
   private String primerNombre;
   private String apellidoPaterno;
   private String numeroSeguroSocial;

   // constructor con tres argumentos
   public Empleado( String nombre, String apellido, String nss )
   {
      primerNombre = nombre;
      apellidoPaterno = apellido;
      numeroSeguroSocial = nss;
   } // fin del constructor de Empleado con tres argumentos

   // establece el primer nombre
   public void establecerPrimerNombre( String nombre )
   {
      primerNombre = nombre;  // debería validar
   } // fin del método establecerPrimerNombre

   // devuelve el primer nombre
   public String obtenerPrimerNombre()
   {
      return primerNombre;
   } // fin del método obtenerPrimerNombre

   // establece el apellido paterno
   public void establecerApellidoPaterno( String apellido )
   {
      apellidoPaterno = apellido;  // debería validar
   } // fin del método establecerApellidoPaterno

   // devuelve el apellido paterno
   public String obtenerApellidoPaterno()
   {
      return apellidoPaterno;
   } // fin del método obtenerApellidoPaterno

   // establece el número de seguro social
   public void establecerNumeroSeguroSocial( String nss )
   {
      numeroSeguroSocial = nss; // debe validar
   } // fin del método establecerNumeroSeguroSocial

   // devuelve el número de seguro social
   public String obtenerNumeroSeguroSocial()
   {
      return numeroSeguroSocial;
   } // fin del método obtenerNumeroSeguroSocial

   // devuelve representación String de un objeto Empleado
   @Override
   public String toString()
   {
      return String.format( "%s %s\nnumero de seguro social: %s", 
         obtenerPrimerNombre(), obtenerApellidoPaterno(), obtenerNumeroSeguroSocial() );
   } // fin del método toString

   // Nota: Aquí no implementamos el método obtenerMontoPago de PorPagar, así que
   // esta clase debe declararse como abstract para evitar un error de compilación.
} // fin de la clase abstracta Empleado
////////////////////////////////////////////////////////////////////////////////////////////////////////////

class EmpleadoAsalariado extends Empleado 
{
   private double salarioSemanal;
   private double impuesto;

   // constructor con cuatro argumentos
   public EmpleadoAsalariado( String nombre, String apellido, String nss,double salario, double imp )
   {
      super( nombre, apellido, nss ); // pasa argumentos al constructor de Empleado
      establecerSalarioSemanal( salario );// valida y almacena el salario
      setImpuesto( imp );
   } // fin del constructor de EmpleadoAsalariado con cuatro argumentos

    public void setImpuesto(double imp){
        if ( imp >= 0)
            impuesto = imp;
        else    
            throw new IllegalArgumentException( "El impuesto debe ser >=0" );
    }
    
    public double getImpuestos(){
        return obtenerSalarioSemanal()*impuesto;
    }

   // establece el salario
   public void establecerSalarioSemanal( double salario )
   {
      if (salario >= 0.0 )
         salarioSemanal = salario;
      else
         throw new IllegalArgumentException(
            "El salario semanal debe ser >= 0.0" );
   } // fin del método establecerSalarioSemanal

   // devuelve el salario
   public double obtenerSalarioSemanal()
   {
      return salarioSemanal;
   } // fin del método obtenerSalarioSemanal

   // calcula los ingresos; implementa el método de la interfaz PorPagar
   // que era abstracto en la superclase Empleado
   @Override
   public double obtenerMontoPago()
   {
      return obtenerSalarioSemanal();
   } // fin del método obtenerMontoPago

   // devuelve representación String de un objeto EmpleadoAsalariado
   @Override
   public String toString()
   {
      return String.format( "empleado asalariado: %s\n%s: $%,.2f\n%s: $%,.2f", 
         super.toString(), "salario semanal", obtenerSalarioSemanal(), "impuesto", getImpuestos() );
   } // fin del método toString
} // fin de la clase EmpleadoAsalariado

