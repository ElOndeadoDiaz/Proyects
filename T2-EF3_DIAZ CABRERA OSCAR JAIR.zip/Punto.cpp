#include<cstdlib>
#include<iostream>

using namespace std;

class Punto{				//nombre de la clase
	public:					//zona publica con declaracion de funciones miembro
		float obtenerX(){			//selector xb
			return x;
		}
		float obtenerY(){
			return y;			//selector y
		}
		float obtenerZ(){
			return z;			//selector z
		}
		void ponerX(float valx){		//modificador x
			x=valx;
		}
		void ponerY(float valy){		//modificador y
			y=valy;
		}
		void ponerZ(float valz){		//modificador z
			z=valz;
		}
		
		Punto(float valx): x(valx), y(0.0), z(0.0){		//constructor
		}												//constructor que inicializa miembros
							//las declaraciones anteriores son definiciones de metodos, ya que
						// incluyen el cuerpo de cada funcion. Son funciones en linea, inline
		
		Punto();					//constructor por defecto
		Punto(float, float, float);	//constructor alternativo
		Punto(const Punto &p);		//constructor copia
		void escribirPunto();		//selector
		void asignarPunto(float, float, float);	//modificador
		
		//las declaraciones anteriores no incluyen el cuerpo de cada funcion
		//son funciones fuera de linea. El cuerpo de la funcion de declara indep.
		
		private:						//zona privada de atributos
			float x,y,z;
};

Punto::Punto(){
	x=0;
	y=0;				//cuerpo constructor por defecto
	z=0;
}

Punto::Punto(float valx, float valy, float valz){
	x=valx;
	y=valy;				//cuerpo constructor alternativo
	z=valz;
}

Punto::Punto(const Punto &p){
	x=p.x;
	y=p.y;				//cuerpo del constructor copia
	z=p.z;
}

void Punto::escribirPunto(){
	cout<<" "<<obtenerX()<< " " << obtenerY()<< " " << obtenerZ()<< endl;		//cuerpo
}

void Punto::asignarPunto(float valx, float valy, float valz){
	//cuerpo. el nombre de los parametros puede omotirse en declaracion
	
	x=valx;
	y=valy;
	z=valz;
}

//////////////////////////////////////// MAIN
int main(int argc, char **argv){
	
	Punto p, p1;		//son objetos de la clase Punto
	Punto p2= Punto(5.0, 6.0, 7.0); //objeto de la clase Punto
	Punto p3(8.0);				//objeto de la clase Punto
	
	p.asignarPunto(2.0,3.0,4.0);	//llamada a funcion miembro
	p.escribirPunto();				//llamada a funcion miembro
	p1.escribirPunto();				//escribe valores constructor por defecto
	p2.escribirPunto();				//escribe valores constructor alternativo
	p3.escribirPunto();				//escribe valores constructor lista
	system("PAUSE");
	return EXIT_SUCCESS;
}