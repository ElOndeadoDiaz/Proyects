#include<cstdlib>
#include<iostream>

using namespace std;

class Contador{
	
	private:
		unsigned int cuenta;		//contar
	
	public:
		Contador(){
			cuenta=0;		//constructor
		}
		void incrementa(){
			cuenta++;		//iterador
		}
		int valor(){
			return cuenta;		//devuelve cuenta
		}
		~Contador(){
		}				//destructor
};

/////////////////////////// MAIN
int main(int argc, char **argv){
	
	Contador c;		//define e inicializa a cero
	
	for(int i=0; i<6; i++){
		cout<< " c= "<< c.valor()<<endl;
		c.incrementa();
		if(i==2)
			c=Contador();
	}
	system("PAUSE");
	return 0;
}