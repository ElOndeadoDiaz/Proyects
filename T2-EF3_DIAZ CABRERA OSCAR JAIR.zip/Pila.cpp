#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

#define max 100

class Pila{
	private:
		int cima;
		float a[max];	//maximo de reales
	
	public:
		Pila(){			//constructor e inicializa en 0
			cima=0;
		};
		float sacar();		//para sacar
		void poner(float x);	//meter
		~Pila()  {}			//destructor
};

float Pila::sacar(){
	if (cima<=0){
		cout<<  "ERROR pila vacia\n";
		return -1;
	}
	else
		return a[--cima];
}

void Pila::poner(float x){
	if(cima>=max)
		cout<< "Error pila llena\n"; 
	else
		a[cima++]=x;
}

//////////////////////////////////MAIN
int main(int argc, char **argv){
	
	Pila p;
	
	p.poner(6.0);
	p.poner(5.0);
	cout<< p.sacar()<<endl;
	cout<< p.sacar()<<endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}