#include <cstdlib>
#include <iostream>

using namespace std;

class empleado{
	
	char *nombre;
	char *direccion;
	float sueldo;
	
	public:
		empleado(){
			nombre = new char[0]; nombre = "";
			direccion = new char [0]; direccion = "";
			sueldo =0;
		}
		~empleado(){}
		void ponerNombre(char*s){
			nombre=s;
		}
		void ponerDireccion(char*s){
			direccion=s;
		}
		void ponerSueldo(float s){
			sueldo=s;
		}
		char * Onombre(){
			return nombre;
		}
		char* Odireccion(){
			return direccion;
		}
		float Osueldo(){
			return sueldo;
		}
		void leerDatos();
		void visualizarDatos();		
};

void empleado::leerDatos(){
	char nombre[50], *s;
	float su;
	
	cout<< "Introduzca nombre: ";
	cin.getline(nombre,49);
	s = new char(strlen(nombre)+1);		//memoria dinamica
	strcpy(s,nombre);		//copia el nombre a la variable s
	ponerNombre(s);
	
	cout<< "Introduzca direccion: ";
	cin.getline(nombre,49);
	s=new char(strlen(nombre)+1);
	strcpy(s, nombre);
	ponerDireccion(s);
	
	cout<< "Sueldo: ";
	cin>>su;
	cin.getline(nombre,2);		//limpiar buffer de entrada
	ponerSueldo(su);
}

void empleado::visualizarDatos(){
	cout<< "Nombre: "<<Onombre()<<endl;
	cout<< "Direccion: "<<Odireccion()<<endl;
	cout<< "Sueldo: "<<Osueldo()<<endl;
}

//////////////////// MAIN
int main(int argc, char **argv){
	empleado Empleados[50];
	int i;
	
	for(i=0; i<50; i++)
		Empleados[i].leerDatos();
	for(i=0; i<50; i++)
		Empleados[i].visualizarDatos();
	system("PAUSE");
	return 0;
}